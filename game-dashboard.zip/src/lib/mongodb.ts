/**
 * MongoDB connection utility — connects to the same database as the Discord bot
 * Uses the same schema: guilds, users collections with guild_id + user_id keys
 */
import { MongoClient, Db } from 'mongodb';

const MONGO_URI = process.env.MONGO_URI || '';
const DB_NAME = process.env.MONGO_DB_NAME || 'vvt158214';

let client: MongoClient | null = null;
let db: Db | null = null;

export async function connectToDatabase(): Promise<Db> {
  if (db) return db;

  try {
    client = new MongoClient(MONGO_URI, {
      tlsAllowInvalidCertificates: true,
      serverSelectionTimeoutMS: 15000,
      connectTimeoutMS: 15000,
      socketTimeoutMS: 30000,
      maxPoolSize: 10,
      minPoolSize: 2,
      retryWrites: true,
      retryReads: true,
    });

    await client.connect();
    db = client.db(DB_NAME);
    console.log('✅ MongoDB connected successfully!');
    return db;
  } catch (error) {
    console.error('❌ MongoDB connection failed:', error);
    throw error;
  }
}

export function getDb(): Db | null {
  return db;
}

// ──── Default user (same as bot's database.py) ────
export function getDefaultUser(guildId: string, userId: string) {
  return {
    guild_id: guildId,
    user_id: userId,
    coins: 0,
    inventory: [],
    rod: 'normal',
    owned_rods: ['normal'],
    bait: 'none',
    baits: { common: 0, premium: 0, legendary: 0 },
    daily_quests: {
      catch_fish: { progress: 0, goal: 5, reward: 10, claimed: false },
      sell_fish: { progress: 0, goal: 10, reward: 50, claimed: false },
      catch_mythic: { progress: 0, goal: 1, reward: 100, claimed: false },
    },
    xp: 0,
    level: 1,
    bank_coins: 0,
    cave_unlocked: false,
    minerals: {},
    tools: { tnt: 0, tnt_1ton: 0, nukeclear: 0 },
    pickpocket_tools: { ec: 0, ec_remaining: 0, coinserver: 0, coinserver_remaining: 0 },
    debt_coins: 0,
    loan_coins: 0,
  };
}

// ──── Default guild (same as bot's database.py) ────
export function getDefaultGuild(guildId: string) {
  return {
    _id: guildId,
    settings: { symbol: '💰' },
    weather: { active: null, intensity: 0 },
    shop: [],
    level_system: {
      enabled: false,
      level_up_channel_id: null,
      level_up_message: 'Chúc mừng {user} đã lên **{level}** tại {server}!',
      role_rewards: {},
    },
  };
}
