import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Game Dashboard — Câu Cá, Rèn, Lab & Hang Động",
  description: "Discord Bot Game Dashboard — Câu cá, phòng thí nghiệm, rèn dụng cụ, hang động và hệ thống kinh tế.",
  keywords: ["Discord Bot", "Game Dashboard", "Câu Cá", "Phòng Lab", "Rèn Dụng Cụ", "Hang Động", "Economy"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Game Dashboard",
    description: "Discord Bot Game Dashboard — Câu cá, rèn, lab, hang động",
    url: "https://chat.z.ai",
    siteName: "Game Dashboard",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Game Dashboard",
    description: "Discord Bot Game Dashboard — Câu cá, rèn, lab, hang động",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
