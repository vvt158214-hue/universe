/**
 * GET /api/economy — Get economy data (coins, bank, inventory, etc.)
 * POST /api/economy — Economy actions (sell fish, deposit, withdraw)
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase, getDefaultUser } from '@/lib/mongodb';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const guildId = searchParams.get('guildId');
    const userId = searchParams.get('userId');

    if (!guildId || !userId) {
      return NextResponse.json({ error: 'Missing guildId or userId' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');
    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });

    if (!userData) {
      userData = getDefaultUser(guildId, userId);
      await usersCol.insertOne(userData);
    }

    return NextResponse.json({
      coins: (userData as any).coins || 0,
      bank_coins: (userData as any).bank_coins || 0,
      level: (userData as any).level || 1,
      xp: (userData as any).xp || 0,
      rod: (userData as any).rod || 'normal',
      owned_rods: (userData as any).owned_rods || ['normal'],
      bait: (userData as any).bait || 'none',
      baits: (userData as any).baits || { common: 0, premium: 0, legendary: 0 },
      inventory: (userData as any).inventory || [],
      inventory_count: ((userData as any).inventory || []).length,
    });
  } catch (error: any) {
    console.error('Error fetching economy:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { guildId, userId, action, amount } = await request.json();

    if (!guildId || !userId || !action) {
      return NextResponse.json({ error: 'Missing required params' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });
    if (!userData) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    let coins = (userData as any).coins || 0;
    let bankCoins = (userData as any).bank_coins || 0;
    let message = '';

    switch (action) {
      case 'deposit': {
        const depositAmount = Math.min(amount || 0, coins);
        if (depositAmount <= 0) {
          return NextResponse.json({ error: 'Số tiền không hợp lệ!' }, { status: 400 });
        }
        coins -= depositAmount;
        bankCoins += depositAmount;
        message = `Đã gửi ${depositAmount.toLocaleString()} coins vào ngân hàng!`;
        break;
      }
      case 'withdraw': {
        const withdrawAmount = Math.min(amount || 0, bankCoins);
        if (withdrawAmount <= 0) {
          return NextResponse.json({ error: 'Số tiền không hợp lệ!' }, { status: 400 });
        }
        bankCoins -= withdrawAmount;
        coins += withdrawAmount;
        message = `Đã rút ${withdrawAmount.toLocaleString()} coins từ ngân hàng!`;
        break;
      }
      case 'sell_all_fish': {
        const inventory = (userData as any).inventory || [];
        let totalValue = 0;
        for (const fish of inventory) {
          totalValue += fish.value || 0;
        }
        coins += totalValue;
        await usersCol.updateOne(
          { guild_id: guildId, user_id: userId },
          { $inc: { coins: totalValue }, $set: { inventory: [] } }
        );
        return NextResponse.json({
          success: true,
          message: `Đã bán ${inventory.length} cá, nhận ${totalValue.toLocaleString()} coins!`,
          coins: coins + totalValue,
          bank_coins: bankCoins,
        });
      }
      default:
        return NextResponse.json({ error: 'Action không hợp lệ!' }, { status: 400 });
    }

    await usersCol.updateOne(
      { guild_id: guildId, user_id: userId },
      { $set: { coins, bank_coins: bankCoins } }
    );

    return NextResponse.json({ success: true, message, coins, bank_coins: bankCoins });
  } catch (error: any) {
    console.error('Error in economy action:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
