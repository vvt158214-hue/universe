/**
 * POST /api/lab — Lab extraction (web version)
 * Get chemistry problems and process answers
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';

const CHEMISTRY_PROBLEMS = [
  { q: 'Ký hiệu hóa học của Sắt là gì?', a: 'Fe', difficulty: 1 },
  { q: 'Ký hiệu hóa học của Vàng là gì?', a: 'Au', difficulty: 1 },
  { q: 'Ký hiệu hóa học của Đồng là gì?', a: 'Cu', difficulty: 1 },
  { q: 'Ký hiệu hóa học của Bạc là gì?', a: 'Ag', difficulty: 1 },
  { q: 'Ký hiệu hóa học của Nhôm là gì?', a: 'Al', difficulty: 1 },
  { q: 'Ký hiệu hóa học của Carbon là gì?', a: 'C', difficulty: 1 },
  { q: 'Cân bằng: H2 + O2 → H2O. Hệ số của H2O là?', a: '2', difficulty: 2 },
  { q: 'Cân bằng: Fe + O2 → Fe2O3. Hệ số của Fe là?', a: '4', difficulty: 2 },
  { q: 'Cân bằng: N2 + H2 → NH3. Hệ số của NH3 là?', a: '2', difficulty: 2 },
  { q: 'Sản phẩm của Fe + CuSO4 là FeSO4 + ...?', a: 'Cu', difficulty: 3 },
  { q: 'Khi đốt C trong O2 dư tạo ra khí gì? (công thức)', a: 'CO2', difficulty: 3 },
  { q: 'NaOH + HCl → NaCl + ...? (công thức)', a: 'H2O', difficulty: 3 },
  { q: 'Cân bằng: Fe2O3 + CO → Fe + CO2. Hệ số của CO là?', a: '3', difficulty: 4 },
  { q: 'Cân bằng: Al + HCl → AlCl3 + H2. Hệ số của HCl là?', a: '6', difficulty: 4 },
  { q: 'Số oxi hóa của Mn trong KMnO4 là?', a: '+7', difficulty: 5 },
  { q: 'Số oxi hóa của Cr trong K2Cr2O7 là?', a: '+6', difficulty: 5 },
];

const MINERALS = [
  { symbol: 'C', name: 'Carbon', rarity: 1, value: 3 },
  { symbol: 'Al', name: 'Aluminium', rarity: 1, value: 5 },
  { symbol: 'Fe', name: 'Iron', rarity: 1, value: 8 },
  { symbol: 'Cu', name: 'Copper', rarity: 2, value: 22 },
  { symbol: 'Ag', name: 'Silver', rarity: 2, value: 50 },
  { symbol: 'Au', name: 'Gold', rarity: 3, value: 100 },
  { symbol: 'Pt', name: 'Platinum', rarity: 3, value: 150 },
  { symbol: 'Li', name: 'Lithium', rarity: 4, value: 300 },
  { symbol: 'U', name: 'Uranium', rarity: 5, value: 500 },
  { symbol: 'Pu', name: 'Plutonium', rarity: 5, value: 800 },
];

const TEST_TUBE_COST: Record<number, number> = { 1: 5, 2: 15, 3: 50, 4: 150, 5: 500 };

export async function POST(request: NextRequest) {
  try {
    const { guildId, userId, mineralSymbol, answers } = await request.json();
    if (!guildId || !userId || !mineralSymbol) {
      return NextResponse.json({ error: 'Missing required params' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });
    if (!userData) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const mineral = MINERALS.find(m => m.symbol === mineralSymbol);
    if (!mineral) {
      return NextResponse.json({ error: 'Mineral not found' }, { status: 404 });
    }

    // Check if user has this mineral
    const minerals = (userData as any).minerals || {};
    if (!minerals[mineralSymbol] || minerals[mineralSymbol].amount <= 0) {
      return NextResponse.json({ error: 'Bạn không có khoáng sản này!' }, { status: 400 });
    }

    // If answers provided, validate them
    if (answers && answers.length > 0) {
      const difficulty = mineral.rarity;
      const problems = CHEMISTRY_PROBLEMS.filter(p => p.difficulty <= difficulty + 1);
      let correct = 0;
      for (const ans of answers) {
        const problem = problems.find(p => p.q === ans.question);
        if (problem && problem.a.toLowerCase() === ans.answer.toLowerCase()) {
          correct++;
        }
      }

      const needed = Math.min(difficulty, problems.length);
      if (correct >= needed) {
        // Success — extract and add coins
        const coinReward = mineral.value * 10;
        minerals[mineralSymbol].amount = Math.max(0, (minerals[mineralSymbol].amount || 0) - 1);

        await usersCol.updateOne(
          { guild_id: guildId, user_id: userId },
          { $inc: { coins: coinReward }, $set: { minerals } }
        );

        return NextResponse.json({ success: true, correct, total: needed, coinReward, message: 'Chiết xuất thành công!' });
      } else {
        return NextResponse.json({ success: false, correct, total: needed, message: 'Chiết xuất thất bại! Câu trả lời chưa đủ.' });
      }
    }

    // Return problems for the client to answer
    const difficulty = mineral.rarity;
    const numProblems = Math.min(difficulty + 1, 3);
    const availableProblems = CHEMISTRY_PROBLEMS.filter(p => p.difficulty <= difficulty + 1);
    const selectedProblems = [];
    const used = new Set<number>();
    while (selectedProblems.length < numProblems && used.size < availableProblems.length) {
      const idx = Math.floor(Math.random() * availableProblems.length);
      if (!used.has(idx)) {
        used.add(idx);
        selectedProblems.push({ question: availableProblems[idx].q });
      }
    }

    return NextResponse.json({
      mineral,
      problems: selectedProblems,
      tubeCost: TEST_TUBE_COST[mineral.rarity] || 5,
    });
  } catch (error: any) {
    console.error('Error in lab:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const guildId = searchParams.get('guildId');
    const userId = searchParams.get('userId');

    if (!guildId || !userId) {
      return NextResponse.json({ error: 'Missing guildId or userId' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');
    const userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });

    if (!userData) {
      return NextResponse.json({ minerals: {}, cave_unlocked: false });
    }

    return NextResponse.json({
      minerals: (userData as any).minerals || {},
      cave_unlocked: (userData as any).cave_unlocked || false,
      tools: (userData as any).tools || { tnt: 0, tnt_1ton: 0, nukeclear: 0 },
    });
  } catch (error: any) {
    console.error('Error getting lab data:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
