/**
 * GET /api/guilds — Get guild data from MongoDB
 * Query params: guildId
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase, getDefaultGuild } from '@/lib/mongodb';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const guildId = searchParams.get('guildId');

    if (!guildId) {
      return NextResponse.json({ error: 'Missing guildId' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const guildsCol = db.collection('guilds');

    let data = await guildsCol.findOne({ _id: guildId });

    if (!data) {
      data = getDefaultGuild(guildId);
      await guildsCol.insertOne(data);
    }

    const { _id, ...guildData } = data as any;
    return NextResponse.json(guildData);
  } catch (error: any) {
    console.error('Error fetching guild:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
