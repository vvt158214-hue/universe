/**
 * POST /api/forge — Forge items (web version)
 * GET — Get forge recipes and hammer data
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';

const FORGE_RECIPES: Record<string, any> = {
  mythical_Fe: { name: '🪄 Cần Câu Sắt Rèn', tool_key: 'mythical', element: 'Fe', tubes_needed: 3, effect: 'Giảm 20% thời gian câu cá, +10% chance Mythic' },
  mythical_Au: { name: '🪄 Cần Câu Vàng Rèn', tool_key: 'mythical', element: 'Au', tubes_needed: 5, effect: 'Giảm 25% thời gian, +15% Mythic, cá nặng x1.5' },
  mythical_Pt: { name: '🪄 Cần Câu Bạch Kim Rèn', tool_key: 'mythical', element: 'Pt', tubes_needed: 5, effect: 'Giảm 30% thời gian, +20% Mythic, +5% Secret' },
  mysterious_Fe: { name: '✨ Cần Câu Bí Ẩn Sắt Rèn', tool_key: 'mysterious', element: 'Fe', tubes_needed: 5, effect: 'Giảm 20% thời gian, +10% Mythic+Secret' },
  mysterious_Au: { name: '✨ Cần Câu Bí Ẩn Vàng Rèn', tool_key: 'mysterious', element: 'Au', tubes_needed: 8, effect: 'Giảm 30% thời gian, +20% Mythic, +10% Secret, cá nặng x2' },
  mysterious_Pt: { name: '✨ Cần Câu Bí Ẩn Bạch Kim Rèn', tool_key: 'mysterious', element: 'Pt', tubes_needed: 10, effect: 'Giảm 40% thời gian, +25% Mythic, +15% Secret, cá nặng x2.5' },
  mysterious_U: { name: '✨ Cần Câu Phóng Xạ', tool_key: 'mysterious', element: 'U', tubes_needed: 12, effect: '☢️ Giảm 50% thời gian, +30% Mythic, +20% Secret, cá nặng x3' },
  tnt_Fe: { name: '🧨 TNT Sắt Rèn', tool_key: 'tnt', element: 'Fe', tubes_needed: 3, effect: 'Đường kính nổ x1.5, phạt giảm 50%' },
  tnt_1ton_W: { name: '💣 TNT 1 Tấn Vonfram Rèn', tool_key: 'tnt_1ton', element: 'W', tubes_needed: 8, effect: 'Đường kính nổ x2, phạt giảm 50%' },
  tnt_1ton_Au: { name: '💣 TNT 1 Tấn Vàng Rèn', tool_key: 'tnt_1ton', element: 'Au', tubes_needed: 10, effect: 'Đường kính nổ x2.5, +30% khoáng sản hiếm' },
  nukeclear_U: { name: '☢️ NukeClear Uranium Rèn', tool_key: 'nukeclear', element: 'U', tubes_needed: 15, effect: '☢️ Đường kính nổ x2, không bị hiệu ứng phóng xạ' },
  nukeclear_Pu: { name: '☢️ NukeClear Plutonium Rèn', tool_key: 'nukeclear', element: 'Pu', tubes_needed: 20, effect: '☢️ Đường kính nổ x3, miễn phóng xạ, không phạt khi sai' },
};

const HAMMERS: Record<string, any> = {
  stone_hammer: { name: 'Búa Đá', emoji: '🔨', price_ec: 50, timing_window: 0.40, forge_bonus: 0 },
  iron_hammer: { name: 'Búa Sắt', emoji: '⚒️', price_ec: 200, timing_window: 0.28, forge_bonus: 10 },
  diamond_hammer: { name: 'Búa Kim Cương', emoji: '💎', price_ec: 1000, timing_window: 0.18, forge_bonus: 25 },
};

export async function GET() {
  return NextResponse.json({ recipes: FORGE_RECIPES, hammers: HAMMERS });
}

export async function POST(request: NextRequest) {
  try {
    const { guildId, userId, recipeKey, timingSuccess } = await request.json();
    if (!guildId || !userId || !recipeKey) {
      return NextResponse.json({ error: 'Missing required params' }, { status: 400 });
    }

    const recipe = FORGE_RECIPES[recipeKey];
    if (!recipe) {
      return NextResponse.json({ error: 'Công thức không tồn tại!' }, { status: 404 });
    }

    if (!timingSuccess) {
      return NextResponse.json({ success: false, message: 'Rèn thất bại! Timing chưa chuẩn.' });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });
    if (!userData) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Update owned rods if it's a rod recipe
    const updateData: any = {};
    if (recipe.tool_key === 'mythical' || recipe.tool_key === 'mysterious') {
      const ownedRods = (userData as any).owned_rods || ['normal'];
      if (!ownedRods.includes(recipe.tool_key)) {
        ownedRods.push(recipe.tool_key);
      }
      updateData.owned_rods = ownedRods;
      updateData.rod = recipe.tool_key;
    }

    if (Object.keys(updateData).length > 0) {
      await usersCol.updateOne(
        { guild_id: guildId, user_id: userId },
        { $set: updateData }
      );
    }

    return NextResponse.json({
      success: true,
      message: `Rèn thành công: ${recipe.name}!`,
      recipe,
    });
  } catch (error: any) {
    console.error('Error forging:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
