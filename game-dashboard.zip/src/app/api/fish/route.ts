/**
 * POST /api/fish — Go fishing (web version of the bot's fishing command)
 * Uses the same fish_data and logic as the Discord bot
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase, getDefaultUser } from '@/lib/mongodb';

// Fish data (from bot's fish_data.py)
const FISH_LIST = [
  { name: 'Cá chép', rank: 'Common', value_range: [1, 10] },
  { name: 'Cá hồi', rank: 'Common', value_range: [1, 10] },
  { name: 'Cá trắm', rank: 'Common', value_range: [1, 10] },
  { name: 'Cá mè', rank: 'Common', value_range: [1, 10] },
  { name: 'Cá lóc', rank: 'Common', value_range: [1, 10] },
  { name: 'Cá thu', rank: 'Uncommon', value_range: [10, 15] },
  { name: 'Cá ngừ', rank: 'Uncommon', value_range: [10, 15] },
  { name: 'Cá vàng', rank: 'Uncommon', value_range: [10, 15] },
  { name: 'Cá mập', rank: 'Rare', value_range: [15, 20] },
  { name: 'Cá rồng', rank: 'Rare', value_range: [15, 20] },
  { name: 'Cá voi', rank: 'Legendary', value_range: [20, 25] },
  { name: 'Cá heo', rank: 'Legendary', value_range: [20, 25] },
  { name: 'Cá kim long', rank: 'Mythic', value_range: [25, 30] },
  { name: 'Cá thần', rank: 'Mythic', value_range: [25, 30] },
  { name: 'Cá bạch tạng', rank: 'Secret', value_range: [30, 50] },
  { name: 'Cá cầu vồng', rank: 'Secret', value_range: [30, 50] },
  { name: '👑The First of the Fish', rank: 'KING', value_range: [99999999999999, 99999999999999] },
];

const RANK_COLORS: Record<string, string> = {
  Common: '#b0b0b0',
  Uncommon: '#4CAF50',
  Rare: '#2196F3',
  Legendary: '#FFD700',
  Mythic: '#9C27B0',
  Secret: '#FF1493',
  KING: '#FF0000',
};

const RODS: Record<string, any> = {
  normal: { name: 'Normal Fishing Rod', emoji: '🎣', unlock_mythic: false, unlock_secret: false },
  mythical: { name: 'Mythical Fishing Rod', emoji: '🪄', unlock_mythic: true, unlock_secret: false },
  mysterious: { name: 'Mysterious Fishing Rod', emoji: '✨', unlock_mythic: true, unlock_secret: true },
};

function pickRandomFish(currentRod: string = 'normal') {
  const rodInfo = RODS[currentRod] || RODS.normal;
  const rankWeights: Record<string, number> = {
    Common: 40, Uncommon: 35, Rare: 30, Legendary: 20,
    Mythic: rodInfo.unlock_mythic ? 10 : 0,
    Secret: rodInfo.unlock_secret ? 1 : 0,
  };
  const available = Object.entries(rankWeights).filter(([, w]) => w > 0);
  const chosenRank = weightedRandom(available.map(([, w]) => w), available.map(([r]) => r));
  const rankFish = FISH_LIST.filter(f => f.rank === chosenRank);
  const fish = rankFish[Math.floor(Math.random() * rankFish.length)];
  const coin = Math.floor(Math.random() * (fish.value_range[1] - fish.value_range[0] + 1)) + fish.value_range[0];
  const kg = Math.round((Math.random() * 99.9 + 0.1) * 10) / 10;
  return { name: fish.name, rank: fish.rank, coin, kg, color: RANK_COLORS[fish.rank] || '#ffffff' };
}

function weightedRandom(weights: number[], items: string[]): string {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < weights.length; i++) {
    r -= weights[i];
    if (r <= 0) return items[i];
  }
  return items[items.length - 1];
}

export async function POST(request: NextRequest) {
  try {
    const { guildId, userId } = await request.json();
    if (!guildId || !userId) {
      return NextResponse.json({ error: 'Missing guildId or userId' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });
    if (!userData) {
      userData = getDefaultUser(guildId, userId);
      await usersCol.insertOne(userData);
    }

    const currentRod = (userData as any).rod || 'normal';
    const fish = pickRandomFish(currentRod);

    // Add fish to inventory and coins
    const inventory = (userData as any).inventory || [];
    inventory.push({ name: fish.name, rank: fish.rank, value: fish.coin, kg: fish.kg, caught_at: new Date().toISOString() });

    await usersCol.updateOne(
      { guild_id: guildId, user_id: userId },
      {
        $inc: { coins: fish.coin },
        $set: { inventory },
      }
    );

    return NextResponse.json({
      success: true,
      fish,
      totalCoins: ((userData as any).coins || 0) + fish.coin,
      inventoryCount: inventory.length,
    });
  } catch (error: any) {
    console.error('Error fishing:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
