/**
 * NextAuth Discord OAuth2 configuration
 * Uses the bot's Discord Client ID and Secret
 */
import NextAuth, { NextAuthOptions } from 'next-auth';
import DiscordProvider from 'next-auth/providers/discord';

export const authOptions: NextAuthOptions = {
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID || '',
      clientSecret: process.env.DISCORD_CLIENT_SECRET || '',
      authorization: {
        params: {
          scope: 'identify identify.premium guilds',
        },
      },
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async jwt({ token, account }) {
      if (account) {
        token.accessToken = account.access_token;
        token.refreshToken = account.refresh_token;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user && token.accessToken) {
        // Fetch user's guilds from Discord API
        try {
          const res = await fetch('https://discord.com/api/v10/users/@me/guilds', {
            headers: { Authorization: `Bearer ${token.accessToken}` },
          });
          if (res.ok) {
            const guilds = await res.json();
            (session as any).guilds = guilds;
          }
        } catch (e) {
          console.error('Failed to fetch guilds:', e);
        }

        // Fetch full user profile (for avatar, discriminator, etc.)
        try {
          const res = await fetch('https://discord.com/api/v10/users/@me', {
            headers: { Authorization: `Bearer ${token.accessToken}` },
          });
          if (res.ok) {
            const userData = await res.json();
            (session as any).discordUser = userData;
          }
        } catch (e) {
          console.error('Failed to fetch user data:', e);
        }
      }
      return session;
    },
  },
  pages: {
    signIn: '/',
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
