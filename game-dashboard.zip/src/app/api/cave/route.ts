/**
 * POST /api/cave — Cave mining with TNT (web version)
 * Uses same logic as bot's fishing.py cave commands
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase, getDefaultUser } from '@/lib/mongodb';

const MINERALS = [
  { symbol: 'C', name: 'Carbon', rarity: 1, value: 3, category: 'solid' },
  { symbol: 'Al', name: 'Aluminium', rarity: 1, value: 5, category: 'solid' },
  { symbol: 'Si', name: 'Silicon', rarity: 1, value: 4, category: 'solid' },
  { symbol: 'Fe', name: 'Iron', rarity: 1, value: 8, category: 'solid' },
  { symbol: 'Ti', name: 'Titanium', rarity: 1, value: 15, category: 'solid' },
  { symbol: 'Na', name: 'Sodium', rarity: 2, value: 6, category: 'solid' },
  { symbol: 'Cu', name: 'Copper', rarity: 2, value: 22, category: 'solid' },
  { symbol: 'Ag', name: 'Silver', rarity: 2, value: 50, category: 'solid' },
  { symbol: 'Au', name: 'Gold', rarity: 3, value: 100, category: 'solid' },
  { symbol: 'Pt', name: 'Platinum', rarity: 3, value: 150, category: 'solid' },
  { symbol: 'W', name: 'Tungsten', rarity: 3, value: 60, category: 'solid' },
  { symbol: 'Li', name: 'Lithium', rarity: 4, value: 300, category: 'solid' },
  { symbol: 'Eu', name: 'Europium', rarity: 4, value: 400, category: 'solid' },
  { symbol: 'Sc', name: 'Scandium', rarity: 5, value: 600, category: 'solid' },
  { symbol: 'Re', name: 'Rhenium', rarity: 5, value: 850, category: 'solid' },
  { symbol: 'U', name: 'Uranium', rarity: 5, value: 500, category: 'radioactive' },
  { symbol: 'Pu', name: 'Plutonium', rarity: 5, value: 800, category: 'radioactive' },
];

const TOOLS: Record<string, any> = {
  tnt: { name: 'TNT Thường', emoji: '🧨', diameter: 10, price_ec: 10 },
  tnt_1ton: { name: 'TNT 1 Ton', emoji: '💣', diameter: 100, price_ec: 100 },
  nukeclear: { name: 'NukeClear', emoji: '☢️', diameter: 1000, price_ec: 1000 },
};

function pickMinerals(diameter: number, toolType: string) {
  const effectiveDiameter = diameter;
  const numFinds = Math.max(1, Math.min(50, Math.floor(effectiveDiameter / 10)));
  const findChance = Math.min(0.95, 0.3 + (effectiveDiameter / 1000) * 0.65);
  const canFindRadioactive = toolType === 'nukeclear' || (toolType === 'tnt_1ton' && Math.random() < 0.05);

  const found: any[] = [];
  for (let i = 0; i < numFinds; i++) {
    if (Math.random() > findChance) continue;

    let weights: number[];
    if (effectiveDiameter >= 500) weights = [10, 25, 30, 25, 10];
    else if (effectiveDiameter >= 50) weights = [25, 30, 25, 15, 5];
    else weights = [50, 30, 15, 4, 1];

    const chosenRarity = weightedRandom(weights);
    const candidates = MINERALS.filter(m =>
      m.rarity === chosenRarity && (canFindRadioactive || m.category !== 'radioactive')
    );

    if (candidates.length > 0) {
      const mineral = candidates[Math.floor(Math.random() * candidates.length)];
      const amount = Math.floor(Math.random() * (effectiveDiameter >= 100 ? 5 : 3)) + 1;
      found.push({ symbol: mineral.symbol, name: mineral.name, rarity: mineral.rarity, value: mineral.value, amount, category: mineral.category });
    }
  }

  // Merge same minerals
  const merged: Record<string, any> = {};
  for (const m of found) {
    if (merged[m.symbol]) {
      merged[m.symbol].amount += m.amount;
    } else {
      merged[m.symbol] = { ...m };
    }
  }
  return Object.values(merged);
}

function weightedRandom(weights: number[]): number {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < weights.length; i++) {
    r -= weights[i];
    if (r <= 0) return i + 1;
  }
  return weights.length;
}

export async function POST(request: NextRequest) {
  try {
    const { guildId, userId, toolType } = await request.json();
    if (!guildId || !userId || !toolType) {
      return NextResponse.json({ error: 'Missing required params' }, { status: 400 });
    }

    const tool = TOOLS[toolType];
    if (!tool) {
      return NextResponse.json({ error: 'Công cụ không hợp lệ!' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });
    if (!userData) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const tools = (userData as any).tools || { tnt: 0, tnt_1ton: 0, nukeclear: 0 };
    if ((tools[toolType] || 0) <= 0) {
      return NextResponse.json({ error: `Bạn không có ${tool.name}!` }, { status: 400 });
    }

    // Generate math problem based on diameter
    let problem, answer;
    if (tool.diameter <= 10) {
      const a = Math.floor(Math.random() * 50) + 1;
      const b = Math.floor(Math.random() * 50) + 1;
      const op = Math.random() < 0.5 ? '+' : '-';
      answer = op === '+' ? a + b : a - b;
      problem = `${a} ${op} ${b} = ?`;
    } else if (tool.diameter <= 100) {
      const a = Math.floor(Math.random() * 15) + 2;
      const b = Math.floor(Math.random() * 15) + 2;
      answer = a * b;
      problem = `${a} x ${b} = ?`;
    } else {
      const a = Math.floor(Math.random() * 20) + 10;
      const b = Math.floor(Math.random() * 20) + 10;
      answer = a * b;
      problem = `${a} x ${b} = ?`;
    }

    // Use one TNT
    tools[toolType] = Math.max(0, (tools[toolType] || 0) - 1);

    // Pick minerals
    const found = pickMinerals(tool.diameter, toolType);

    // Add minerals to user data
    const minerals = (userData as any).minerals || {};
    for (const m of found) {
      if (minerals[m.symbol]) {
        minerals[m.symbol].amount = (minerals[m.symbol].amount || 0) + m.amount;
      } else {
        minerals[m.symbol] = { name: m.name, rarity: m.rarity, value: m.value, amount: m.amount, category: m.category };
      }
    }

    await usersCol.updateOne(
      { guild_id: guildId, user_id: userId },
      { $set: { tools, minerals } }
    );

    return NextResponse.json({
      success: true,
      tool,
      problem,
      answer, // In real game this would be verified, but for web we send it for the mini-game
      minerals: found,
      totalMinerals: found.reduce((sum: number, m: any) => sum + m.amount, 0),
    });
  } catch (error: any) {
    console.error('Error in cave:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const guildId = searchParams.get('guildId');
    const userId = searchParams.get('userId');

    if (!guildId || !userId) {
      return NextResponse.json({ error: 'Missing params' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');
    const userData = await usersCol.findOne({ guild_id: guildId, user_id: userId });

    return NextResponse.json({
      minerals: (userData as any)?.minerals || {},
      cave_unlocked: (userData as any)?.cave_unlocked || false,
      tools: (userData as any)?.tools || { tnt: 0, tnt_1ton: 0, nukeclear: 0 },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
