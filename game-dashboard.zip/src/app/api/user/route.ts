/**
 * GET /api/user — Get user data from MongoDB for a specific guild
 * Query params: guildId, userId
 */
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase, getDefaultUser } from '@/lib/mongodb';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const guildId = searchParams.get('guildId');
    const userId = searchParams.get('userId');

    if (!guildId || !userId) {
      return NextResponse.json({ error: 'Missing guildId or userId' }, { status: 400 });
    }

    const db = await connectToDatabase();
    const usersCol = db.collection('users');

    let data = await usersCol.findOne({ guild_id: guildId, user_id: userId });

    if (!data) {
      // Create default user
      data = getDefaultUser(guildId, userId);
      await usersCol.insertOne(data);
    }

    // Remove MongoDB _id for client
    const { _id, ...userData } = data as any;
    return NextResponse.json(userData);
  } catch (error: any) {
    console.error('Error fetching user:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
