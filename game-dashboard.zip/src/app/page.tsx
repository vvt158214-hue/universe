'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useSession, signIn, signOut, SessionProvider } from 'next-auth/react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Fish, FlaskConical, Hammer, Mountain, Coins,
  LogOut, ChevronRight, Loader2, Zap, Shield,
  Wallet, Banknote, Package, Trophy, Star,
  Store, ArrowRight, ArrowLeftRight, CheckCircle,
  XCircle, Timer, Gem, Radio, Bomb, AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useGameStore } from '@/store/gameStore';

// ══════════════════════════════════════════════════════════════
//  RANK CONFIG
// ══════════════════════════════════════════════════════════════
const RANK_COLORS: Record<string, string> = {
  Common: 'bg-gray-500/20 text-gray-300 border-gray-500/30',
  Uncommon: 'bg-green-500/20 text-green-300 border-green-500/30',
  Rare: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  Legendary: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  Mythic: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  Secret: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
  KING: 'bg-red-500/20 text-red-300 border-red-500/30',
};

const RANK_GLOW: Record<string, string> = {
  Common: '',
  Uncommon: 'shadow-green-500/20',
  Rare: 'shadow-blue-500/30',
  Legendary: 'shadow-yellow-500/40',
  Mythic: 'shadow-purple-500/40',
  Secret: 'shadow-pink-500/40',
  KING: 'shadow-red-500/50',
};

const RARITY_COLORS: Record<number, string> = {
  1: 'bg-gray-500/20 text-gray-300',
  2: 'bg-green-500/20 text-green-300',
  3: 'bg-blue-500/20 text-blue-300',
  4: 'bg-purple-500/20 text-purple-300',
  5: 'bg-yellow-500/20 text-yellow-300',
};

// ══════════════════════════════════════════════════════════════
//  LOGIN SCREEN
// ══════════════════════════════════════════════════════════════
function LoginScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] p-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="bg-[#1e293b]/90 backdrop-blur-xl border-white/10 shadow-2xl">
          <CardHeader className="text-center pb-2">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="mx-auto w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mb-4 shadow-lg shadow-purple-500/30"
            >
              <Fish className="w-10 h-10 text-white" />
            </motion.div>
            <CardTitle className="text-2xl font-bold text-white">
              🎣 Game Dashboard
            </CardTitle>
            <CardDescription className="text-slate-400 mt-2">
              Đăng nhập bằng Discord để chơi game và quản lý tài khoản
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: <Fish className="w-4 h-4" />, label: 'Câu Cá' },
                { icon: <FlaskConical className="w-4 h-4" />, label: 'Phòng Lab' },
                { icon: <Hammer className="w-4 h-4" />, label: 'Rèn Dụng Cụ' },
                { icon: <Mountain className="w-4 h-4" />, label: 'Hang Động' },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="flex items-center gap-2 p-2 rounded-lg bg-white/5 text-slate-300 text-sm"
                >
                  {item.icon} {item.label}
                </motion.div>
              ))}
            </div>
            <Separator className="bg-white/10" />
            <Button
              onClick={() => signIn('discord')}
              className="w-full h-12 text-base font-semibold bg-[#5865F2] hover:bg-[#4752C4] text-white shadow-lg shadow-indigo-500/25 transition-all duration-200 hover:scale-[1.02]"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z" />
              </svg>
              Đăng Nhập Bằng Discord
            </Button>
            <p className="text-xs text-slate-500 text-center">
              Cần quyền identify &amp; guilds để xem server của bạn
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  SERVER SELECTION SCREEN
// ══════════════════════════════════════════════════════════════
function ServerSelectScreen() {
  const { data: session } = useSession();
  const { setGuilds, setSelectedGuild } = useGameStore();
  const sessionGuilds = (session as any)?.guilds;
  const guilds: any[] = sessionGuilds || [];
  const loading = !sessionGuilds;

  useEffect(() => {
    if (sessionGuilds) {
      setGuilds(sessionGuilds);
    }
  }, [sessionGuilds, setGuilds]);

  const selectServer = (guild: any) => {
    setSelectedGuild({
      id: guild.id,
      name: guild.name,
      icon: guild.icon,
      owner: guild.owner,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] p-4">
      <div className="max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10 border-2 border-indigo-500/30">
                <AvatarImage src={session?.user?.image || ''} />
                <AvatarFallback className="bg-indigo-600 text-white">
                  {session?.user?.name?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-white font-semibold">{session?.user?.name}</p>
                <p className="text-slate-400 text-xs">Chọn server để chơi</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => signOut()} className="text-slate-400 hover:text-red-400">
              <LogOut className="w-4 h-4 mr-1" /> Thoát
            </Button>
          </div>

          <Card className="bg-[#1e293b]/90 backdrop-blur-xl border-white/10 shadow-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-400" />
                Chọn Server
              </CardTitle>
              <CardDescription className="text-slate-400">
                Tiền tệ và dữ liệu được lưu theo từng server (guild)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
                </div>
              ) : (
                <ScrollArea className="max-h-[60vh]">
                  <div className="space-y-2">
                    {guilds.map((guild, i) => (
                      <motion.button
                        key={guild.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => selectServer(guild)}
                        className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-transparent hover:border-indigo-500/30 transition-all duration-200 group"
                      >
                        {guild.icon ? (
                          <img
                            src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=64`}
                            alt={guild.name}
                            className="w-10 h-10 rounded-lg"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-indigo-600/50 flex items-center justify-center text-white font-bold text-lg">
                            {guild.name.charAt(0)}
                          </div>
                        )}
                        <div className="flex-1 text-left">
                          <p className="text-white font-medium text-sm">{guild.name}</p>
                          {guild.owner && (
                            <Badge variant="outline" className="text-[10px] h-4 px-1 border-yellow-500/30 text-yellow-400 mt-0.5">
                              Owner
                            </Badge>
                          )}
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                      </motion.button>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  FISHING GAME COMPONENT
// ══════════════════════════════════════════════════════════════
function FishingGame({ guildId, userId }: { guildId: string; userId: string }) {
  const [fishing, setFishing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [animPhase, setAnimPhase] = useState(0);
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/economy?guildId=${guildId}&userId=${userId}`);
        if (res.ok) setUserData(await res.json());
      } catch (e) {}
    };
    fetchData();
  }, [guildId, userId]);

  const goFish = async () => {
    setFishing(true);
    setResult(null);
    setAnimPhase(1);

    await new Promise(r => setTimeout(r, 800));
    setAnimPhase(2);

    await new Promise(r => setTimeout(r, 1200));
    setAnimPhase(3);

    try {
      const res = await fetch('/api/fish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId }),
      });
      const data = await res.json();
      setResult(data);
    } catch (e) {
      setResult({ error: 'Lỗi kết nối!' });
    }
    setFishing(false);
    fetchUserData();
  };

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: <Coins className="w-4 h-4 text-yellow-400" />, label: 'Coins', value: (userData?.coins || 0).toLocaleString() },
          { icon: <Fish className="w-4 h-4 text-cyan-400" />, label: 'Cá', value: userData?.inventory_count || 0 },
          { icon: <Star className="w-4 h-4 text-purple-400" />, label: 'Level', value: userData?.level || 1 },
        ].map((s, i) => (
          <Card key={i} className="bg-white/5 border-white/10">
            <CardContent className="p-3 flex items-center gap-2">
              {s.icon}
              <div>
                <p className="text-[10px] text-slate-400">{s.label}</p>
                <p className="text-sm font-bold text-white">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Fishing Animation Area */}
      <Card className="bg-gradient-to-b from-cyan-900/30 to-blue-900/30 border-cyan-500/20 overflow-hidden">
        <CardContent className="p-6 text-center min-h-[200px] flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            {!fishing && !result && (
              <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="text-6xl mb-4">🎣</div>
                <p className="text-slate-300 mb-4">Sẵn sàng thả mồi câu cá!</p>
                <Button onClick={goFish} className="bg-cyan-600 hover:bg-cyan-700 text-white shadow-lg shadow-cyan-500/25">
                  <Fish className="w-4 h-4 mr-2" /> Câu Cá
                </Button>
              </motion.div>
            )}

            {fishing && (
              <motion.div key="fishing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {animPhase === 1 && (
                  <motion.div animate={{ y: [0, 10, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
                    <div className="text-6xl mb-4">🎣</div>
                    <p className="text-cyan-300 animate-pulse">Đang thả mồi...</p>
                  </motion.div>
                )}
                {animPhase === 2 && (
                  <motion.div animate={{ rotate: [-5, 5, -5] }} transition={{ repeat: Infinity, duration: 0.3 }}>
                    <div className="text-6xl mb-4">🎣</div>
                    <p className="text-yellow-300 animate-pulse font-bold">Cá đang cắn! Kéo nhanh!</p>
                  </motion.div>
                )}
                {animPhase === 3 && (
                  <div>
                    <Loader2 className="w-12 h-12 animate-spin text-cyan-400 mx-auto mb-2" />
                    <p className="text-cyan-300">Đang kéo cá lên...</p>
                  </div>
                )}
              </motion.div>
            )}

            {!fishing && result && !result.error && (
              <motion.div key="result" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className={`inline-block px-4 py-2 rounded-xl border ${RANK_COLORS[result.fish.rank]} ${RANK_GLOW[result.fish.rank] ? 'shadow-lg ' + RANK_GLOW[result.fish.rank] : ''}`}
                >
                  <p className="text-3xl mb-2">🐟</p>
                  <p className="font-bold text-lg">{result.fish.name}</p>
                  <p className="text-sm opacity-80">{result.fish.rank}</p>
                </motion.div>
                <div className="mt-4 space-y-1 text-sm text-slate-300">
                  <p>💰 Giá trị: <span className="text-yellow-400 font-bold">+{result.fish.coin} coins</span></p>
                  <p>⚖️ Cân nặng: <span className="text-cyan-400">{result.fish.kg} kg</span></p>
                  <p>🎒 Tổng cá: {result.inventoryCount}</p>
                </div>
                <Button onClick={goFish} className="mt-4 bg-cyan-600 hover:bg-cyan-700 text-white">
                  <Fish className="w-4 h-4 mr-2" /> Câu Tiếp
                </Button>
              </motion.div>
            )}

            {!fishing && result?.error && (
              <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <XCircle className="w-12 h-12 text-red-400 mx-auto mb-2" />
                <p className="text-red-400">{result.error}</p>
                <Button onClick={goFish} className="mt-4 bg-cyan-600 hover:bg-cyan-700 text-white">
                  Thử Lại
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Rod Info */}
      {userData && (
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-3">
            <p className="text-xs text-slate-400 mb-1">Cần câu hiện tại</p>
            <p className="text-white text-sm font-medium">
              {userData.rod === 'normal' ? '🎣 Normal Rod' : userData.rod === 'mythical' ? '🪄 Mythical Rod' : '✨ Mysterious Rod'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  LAB / EXTRACTION GAME COMPONENT
// ══════════════════════════════════════════════════════════════
function LabGame({ guildId, userId }: { guildId: string; userId: string }) {
  const [labData, setLabData] = useState<any>(null);
  const [selectedMineral, setSelectedMineral] = useState<string | null>(null);
  const [problems, setProblems] = useState<any[]>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/lab?guildId=${guildId}&userId=${userId}`);
        if (res.ok) {
          const data = await res.json();
          setLabData(data);
        }
      } catch (e) {}
    };
    fetchData();
  }, [guildId, userId]);

  const startExtraction = async (symbol: string) => {
    setSelectedMineral(symbol);
    setLoading(true);
    setProblems(null);
    setResult(null);
    try {
      const res = await fetch('/api/lab', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId, mineralSymbol: symbol }),
      });
      const data = await res.json();
      if (data.problems) {
        setProblems(data.problems);
      } else if (data.success !== undefined) {
        setResult(data);
      }
    } catch (e) {
      setResult({ success: false, message: 'Lỗi kết nối!' });
    }
    setLoading(false);
  };

  const submitAnswers = async () => {
    if (!selectedMineral || !problems) return;
    setLoading(true);
    try {
      const answerList = problems.map(p => ({
        question: p.question,
        answer: answers[p.question] || '',
      }));
      const res = await fetch('/api/lab', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId, mineralSymbol: selectedMineral, answers: answerList }),
      });
      const data = await res.json();
      setResult(data);
    } catch (e) {
      setResult({ success: false, message: 'Lỗi kết nối!' });
    }
    setLoading(false);
  };

  const minerals = labData?.minerals || {};
  const mineralList = Object.entries(minerals).filter(([, v]: any) => v.amount > 0);

  return (
    <div className="space-y-4">
      {/* Lab Header */}
      <Card className="bg-gradient-to-b from-emerald-900/30 to-teal-900/30 border-emerald-500/20">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <FlaskConical className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-white font-semibold">Phòng Thí Nghiệm</p>
              <p className="text-xs text-slate-400">Chiết xuất khoáng sản → coins</p>
            </div>
          </div>
          {!labData?.cave_unlocked && (
            <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-300 text-xs">
              ⚠️ Bạn cần mở khóa Hang Động trước khi dùng Lab!
            </div>
          )}
        </CardContent>
      </Card>

      {/* Mineral List */}
      {!selectedMineral ? (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Khoáng Sản Của Bạn</CardTitle>
          </CardHeader>
          <CardContent>
            {mineralList.length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-4">Chưa có khoáng sản. Hãy vào Hang Động để khai thác!</p>
            ) : (
              <ScrollArea className="max-h-60">
                <div className="space-y-2">
                  {mineralList.map(([symbol, data]: [string, any]) => (
                    <motion.button
                      key={symbol}
                      whileHover={{ scale: 1.01 }}
                      onClick={() => startExtraction(symbol)}
                      className="w-full flex items-center justify-between p-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-transparent hover:border-emerald-500/30 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        <Badge className={`${RARITY_COLORS[data.rarity]} text-[10px] h-5`}>
                          {data.rarity === 1 ? '⬜' : data.rarity === 2 ? '🟩' : data.rarity === 3 ? '🟦' : data.rarity === 4 ? '🟪' : '🟨'}
                        </Badge>
                        <div className="text-left">
                          <p className="text-white text-sm font-medium">{symbol} — {data.name}</p>
                          <p className="text-slate-400 text-[10px]">Value: {data.value} EC/unit</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-mono text-sm">x{data.amount}</span>
                        <ArrowRight className="w-3 h-3 text-slate-500" />
                      </div>
                    </motion.button>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      ) : (
        /* Extraction Problem */
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm text-white">Chiết xuất {selectedMineral}</CardTitle>
              <Button variant="ghost" size="sm" className="text-slate-400" onClick={() => { setSelectedMineral(null); setProblems(null); setResult(null); setAnswers({}); }}>
                ← Quay lại
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-6">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-400" />
              </div>
            ) : problems ? (
              <div className="space-y-3">
                {problems.map((p, i) => (
                  <div key={i} className="p-3 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-white text-sm mb-2">{p.question}</p>
                    <Input
                      placeholder="Câu trả lời..."
                      value={answers[p.question] || ''}
                      onChange={(e) => setAnswers(prev => ({ ...prev, [p.question]: e.target.value }))}
                      className="bg-white/5 border-white/10 text-white h-9"
                    />
                  </div>
                ))}
                <Button onClick={submitAnswers} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                  <FlaskConical className="w-4 h-4 mr-2" /> Chiết Xuất
                </Button>
              </div>
            ) : result ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-4">
                {result.success ? (
                  <>
                    <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
                    <p className="text-emerald-300 font-bold">Thành công!</p>
                    <p className="text-yellow-400">+{result.coinReward} coins</p>
                  </>
                ) : (
                  <>
                    <XCircle className="w-10 h-10 text-red-400 mx-auto mb-2" />
                    <p className="text-red-300 font-bold">Thất bại!</p>
                    <p className="text-slate-400 text-sm">{result.message}</p>
                  </>
                )}
                <Button variant="ghost" className="mt-3 text-slate-400" onClick={() => { setSelectedMineral(null); setProblems(null); setResult(null); }}>
                  Thử lại
                </Button>
              </motion.div>
            ) : null}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  FORGE GAME COMPONENT
// ══════════════════════════════════════════════════════════════
function ForgeGame({ guildId, userId }: { guildId: string; userId: string }) {
  const [recipes, setRecipes] = useState<any>(null);
  const [hammers, setHammers] = useState<any>(null);
  const [forging, setForging] = useState(false);
  const [forgeResult, setForgeResult] = useState<any>(null);
  const [timingGame, setTimingGame] = useState(false);
  const [timingPos, setTimingPos] = useState(0);
  const [timingDirection, setTimingDirection] = useState(1);
  const [selectedRecipe, setSelectedRecipe] = useState<string | null>(null);
  const timingRef = useRef<any>(null);

  useEffect(() => {
    fetch('/api/forge').then(r => r.json()).then(data => {
      setRecipes(data.recipes);
      setHammers(data.hammers);
    }).catch(() => {});
  }, []);

  const startForge = (key: string) => {
    setSelectedRecipe(key);
    setTimingGame(true);
    setForgeResult(null);
    setTimingPos(0);
    setTimingDirection(1);
  };

  useEffect(() => {
    if (!timingGame) return;
    const speed = 3;
    timingRef.current = setInterval(() => {
      setTimingPos(prev => {
        const next = prev + speed * timingDirection;
        if (next >= 100 || next <= 0) {
          setTimingDirection(d => -d);
          return next >= 100 ? 100 : 0;
        }
        return next;
      });
    }, 30);
    return () => clearInterval(timingRef.current);
  }, [timingGame, timingDirection]);

  const hitForge = async () => {
    clearInterval(timingRef.current);
    setTimingGame(false);
    setForging(true);

    // Sweet spot: 35-65%
    const success = timingPos >= 35 && timingPos <= 65;

    try {
      const res = await fetch('/api/forge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId, recipeKey: selectedRecipe, timingSuccess: success }),
      });
      const data = await res.json();
      setForgeResult({ ...data, timingPos, success });
    } catch (e) {
      setForgeResult({ success: false, message: 'Lỗi kết nối!' });
    }
    setForging(false);
  };

  const recipeEntries = recipes ? Object.entries(recipes) : [];

  return (
    <div className="space-y-4">
      {/* Forge Header */}
      <Card className="bg-gradient-to-b from-orange-900/30 to-red-900/30 border-orange-500/20">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <Hammer className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-white font-semibold">Rèn Dụng Cụ</p>
              <p className="text-xs text-slate-400">Rèn cần câu, mồi, TNT nâng cấp</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timing Game */}
      {timingGame && (
        <Card className="bg-white/5 border-orange-500/30">
          <CardContent className="p-4">
            <p className="text-white text-sm mb-3 text-center">🔥 Nhấn RÈN khi thanh ở vùng xanh!</p>
            <div className="relative h-8 bg-white/10 rounded-full overflow-hidden mb-3">
              {/* Sweet spot zone */}
              <div className="absolute left-[35%] w-[30%] h-full bg-green-500/30 border-x-2 border-green-400/50" />
              {/* Moving indicator */}
              <motion.div
                className="absolute top-0 h-full w-1 bg-white shadow-lg shadow-white/50"
                style={{ left: `${timingPos}%` }}
              />
            </div>
            <Button onClick={hitForge} className="w-full bg-orange-600 hover:bg-orange-700 text-white text-lg h-12">
              🔨 RÈN!
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Forge Result */}
      {forgeResult && (
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4 text-center">
            {forgeResult.success ? (
              <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                <CheckCircle className="w-10 h-10 text-orange-400 mx-auto mb-2" />
                <p className="text-orange-300 font-bold text-lg">Rèn Thành Công!</p>
                <p className="text-white text-sm">{forgeResult.recipe?.name}</p>
                <p className="text-slate-400 text-xs mt-1">{forgeResult.recipe?.effect}</p>
              </motion.div>
            ) : (
              <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                <XCircle className="w-10 h-10 text-red-400 mx-auto mb-2" />
                <p className="text-red-300 font-bold">Rèn Thất Bại!</p>
                <p className="text-slate-400 text-sm">Timing chưa chuẩn — thử lại nhé!</p>
              </motion.div>
            )}
            <Button variant="ghost" className="mt-3 text-slate-400" onClick={() => { setForgeResult(null); setSelectedRecipe(null); }}>
              Tiếp tục
            </Button>
          </CardContent>
        </Card>
      )}

      {forging && (
        <div className="flex justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-orange-400" />
        </div>
      )}

      {/* Recipe List */}
      {!timingGame && !forgeResult && !forging && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Công Thức Rèn</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-72">
              <div className="space-y-2">
                {recipeEntries.map(([key, recipe]: [string, any]) => (
                  <motion.button
                    key={key}
                    whileHover={{ scale: 1.01 }}
                    onClick={() => startForge(key)}
                    className="w-full p-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-transparent hover:border-orange-500/30 transition-all text-left"
                  >
                    <p className="text-white text-sm font-medium">{recipe.name}</p>
                    <p className="text-slate-400 text-[10px] mt-0.5">{recipe.effect}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-[10px] h-4 border-orange-500/30 text-orange-300">
                        {recipe.tubes_needed} ống nghiệm
                      </Badge>
                      <Badge variant="outline" className="text-[10px] h-4 border-cyan-500/30 text-cyan-300">
                        {recipe.element}
                      </Badge>
                    </div>
                  </motion.button>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Hammers */}
      {hammers && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Búa Rèn</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(hammers).map(([key, hammer]: [string, any]) => (
                <div key={key} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{hammer.emoji}</span>
                    <div>
                      <p className="text-white text-sm">{hammer.name}</p>
                      <p className="text-slate-400 text-[10px]">Bonus: +{hammer.forge_bonus}%</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] border-yellow-500/30 text-yellow-300">
                    {hammer.price_ec} EC
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  CAVE MINING GAME COMPONENT
// ══════════════════════════════════════════════════════════════
function CaveGame({ guildId, userId }: { guildId: string; userId: string }) {
  const [caveData, setCaveData] = useState<any>(null);
  const [mining, setMining] = useState(false);
  const [mineResult, setMineResult] = useState<any>(null);
  const [mathProblem, setMathProblem] = useState<any>(null);
  const [mathAnswer, setMathAnswer] = useState('');
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/cave?guildId=${guildId}&userId=${userId}`);
        if (res.ok) setCaveData(await res.json());
      } catch (e) {}
    };
    fetchData();
  }, [guildId, userId]);

  const startMining = async (toolType: string) => {
    setSelectedTool(toolType);
    setMining(true);
    setMineResult(null);
    setMathAnswer('');

    try {
      const res = await fetch('/api/cave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId, toolType }),
      });
      const data = await res.json();

      if (data.success) {
        setMathProblem({ question: data.problem, answer: data.answer, tool: data.tool });
        setMineResult(data);
      } else {
        setMineResult(data);
      }
    } catch (e) {
      setMineResult({ error: 'Lỗi kết nối!' });
    }
    setMining(false);
  };

  const tools = caveData?.tools || { tnt: 0, tnt_1ton: 0, nukeclear: 0 };
  const toolDefs = [
    { key: 'tnt', name: 'TNT Thường', emoji: '🧨', diameter: 10, count: tools.tnt },
    { key: 'tnt_1ton', name: 'TNT 1 Ton', emoji: '💣', diameter: 100, count: tools.tnt_1ton },
    { key: 'nukeclear', name: 'NukeClear', emoji: '☢️', diameter: 1000, count: tools.nukeclear },
  ];

  const minerals = caveData?.minerals || {};
  const mineralList = Object.entries(minerals).filter(([, v]: any) => v.amount > 0);

  return (
    <div className="space-y-4">
      {/* Cave Header */}
      <Card className="bg-gradient-to-b from-amber-900/30 to-stone-900/30 border-amber-500/20">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
              <Mountain className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-white font-semibold">Hang Động</p>
              <p className="text-xs text-slate-400">Dùng TNT để khai thác khoáng sản</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TNT Tools */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white">Công Cụ TNT</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {toolDefs.map(tool => (
              <div key={tool.key} className="flex items-center justify-between p-2.5 rounded-lg bg-white/5">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{tool.emoji}</span>
                  <div>
                    <p className="text-white text-sm">{tool.name}</p>
                    <p className="text-slate-400 text-[10px]">Diameter: {tool.diameter}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-300">
                    x{tool.count}
                  </Badge>
                  <Button
                    size="sm"
                    disabled={tool.count <= 0 || mining}
                    onClick={() => startMining(tool.key)}
                    className="h-7 bg-amber-600 hover:bg-amber-700 text-white text-xs"
                  >
                    Nổ!
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Math Problem (from mining) */}
      {mathProblem && (
        <Card className="bg-white/5 border-yellow-500/30 border">
          <CardContent className="p-4">
            <p className="text-white text-sm mb-2">🧮 Giải toán để nhận khoáng sản:</p>
            <p className="text-yellow-300 text-lg font-mono mb-3">{mathProblem.question}</p>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="Đáp án..."
                value={mathAnswer}
                onChange={(e) => setMathAnswer(e.target.value)}
                className="bg-white/5 border-white/10 text-white h-9"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && mathAnswer === String(mathProblem.answer)) {
                    setMathProblem(null);
                  }
                }}
              />
              <Button
                onClick={() => setMathProblem(null)}
                className="bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                OK
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mining Result */}
      {mineResult?.minerals && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-white">Kết Quả Khai Thác</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1.5">
              {mineResult.minerals.map((m: any, i: number) => (
                <div key={i} className="flex items-center justify-between p-2 rounded bg-white/5">
                  <div className="flex items-center gap-2">
                    <Badge className={`${RARITY_COLORS[m.rarity]} text-[10px] h-5`}>
                      R{m.rarity}
                    </Badge>
                    <span className="text-white text-sm">{m.symbol} — {m.name}</span>
                    {m.category === 'radioactive' && <Radio className="w-3 h-3 text-green-400" />}
                  </div>
                  <span className="text-emerald-400 font-mono text-sm">x{m.amount}</span>
                </div>
              ))}
            </div>
            <p className="text-slate-400 text-xs mt-2">Tổng: {mineResult.totalMinerals} khoáng sản</p>
          </CardContent>
        </Card>
      )}

      {/* Your Minerals */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white">Khoáng Sản Của Bạn</CardTitle>
        </CardHeader>
        <CardContent>
          {mineralList.length === 0 ? (
            <p className="text-slate-400 text-sm text-center py-3">Chưa có khoáng sản</p>
          ) : (
            <ScrollArea className="max-h-48">
              <div className="space-y-1.5">
                {mineralList.map(([symbol, data]: [string, any]) => (
                  <div key={symbol} className="flex items-center justify-between p-1.5 rounded bg-white/5 text-sm">
                    <div className="flex items-center gap-1.5">
                      <Badge className={`${RARITY_COLORS[data.rarity]} text-[9px] h-4 px-1`}>
                        {symbol}
                      </Badge>
                      <span className="text-slate-300">{data.name}</span>
                    </div>
                    <span className="text-white font-mono">x{data.amount}</span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  ECONOMY COMPONENT
// ══════════════════════════════════════════════════════════════
function EconomyPanel({ guildId, userId }: { guildId: string; userId: string }) {
  const [ecoData, setEcoData] = useState<any>(null);
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/economy?guildId=${guildId}&userId=${userId}`);
        if (res.ok) setEcoData(await res.json());
      } catch (e) {}
    };
    fetchData();
  }, [guildId, userId]);

  const refreshEco = useCallback(async () => {
    try {
      const res = await fetch(`/api/economy?guildId=${guildId}&userId=${userId}`);
      if (res.ok) setEcoData(await res.json());
    } catch (e) {}
  }, [guildId, userId]);

  const doAction = async (action: string, amt?: number) => {
    try {
      const res = await fetch('/api/economy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, userId, action, amount: amt }),
      });
      const data = await res.json();
      if (data.message || data.error) {
        setMessage(data.message || data.error);
      }
      refreshEco();
    } catch (e) {
      setMessage('Lỗi kết nối!');
    }
  };

  return (
    <div className="space-y-4">
      {/* Wallet Cards */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-yellow-900/30 to-amber-900/30 border-yellow-500/20">
          <CardContent className="p-4 text-center">
            <Wallet className="w-6 h-6 text-yellow-400 mx-auto mb-1" />
            <p className="text-[10px] text-slate-400">Ví</p>
            <p className="text-xl font-bold text-yellow-300">{(ecoData?.coins || 0).toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-emerald-900/30 to-green-900/30 border-emerald-500/20">
          <CardContent className="p-4 text-center">
            <Banknote className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
            <p className="text-[10px] text-slate-400">Ngân Hàng</p>
            <p className="text-xl font-bold text-emerald-300">{(ecoData?.bank_coins || 0).toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Level & XP */}
      <Card className="bg-white/5 border-white/10">
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-400">Level {ecoData?.level || 1}</span>
            <span className="text-xs text-slate-400">{ecoData?.xp || 0} XP</span>
          </div>
          <Progress value={((ecoData?.xp || 0) % 100)} className="h-2" />
        </CardContent>
      </Card>

      {/* Bank Actions */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white">Ngân Hàng</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Số tiền..."
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-white/5 border-white/10 text-white h-9"
            />
            <Button onClick={() => doAction('deposit', parseInt(amount))} className="bg-emerald-600 hover:bg-emerald-700 text-white h-9">
              Gửi
            </Button>
            <Button onClick={() => doAction('withdraw', parseInt(amount))} className="bg-yellow-600 hover:bg-yellow-700 text-white h-9">
              Rút
            </Button>
          </div>
          {message && (
            <p className="text-xs text-slate-300 bg-white/5 p-2 rounded">{message}</p>
          )}
        </CardContent>
      </Card>

      {/* Inventory */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm text-white">
              <Package className="w-4 h-4 inline mr-1" /> Túi Đồ ({ecoData?.inventory_count || 0} cá)
            </CardTitle>
            {(ecoData?.inventory_count || 0) > 0 && (
              <Button size="sm" variant="destructive" className="h-6 text-[10px]" onClick={() => doAction('sell_all_fish')}>
                Bán Tất Cả
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-48">
            {(ecoData?.inventory || []).length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-3">Túi đồ trống</p>
            ) : (
              <div className="space-y-1">
                {(ecoData?.inventory || []).slice(-20).reverse().map((item: any, i: number) => (
                  <div key={i} className="flex items-center justify-between p-1.5 rounded bg-white/5 text-xs">
                    <div className="flex items-center gap-1.5">
                      <Badge className={`${RANK_COLORS[item.rank] || ''} text-[9px] h-4 px-1`}>
                        {item.rank}
                      </Badge>
                      <span className="text-white">{item.name}</span>
                    </div>
                    <span className="text-yellow-400">{item.value}💰</span>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  MAIN GAME DASHBOARD
// ══════════════════════════════════════════════════════════════
function GameDashboard() {
  const { data: session } = useSession();
  const { selectedGuild, setSelectedGuild, setUserData } = useGameStore();
  const [activeTab, setActiveTab] = useState('fishing');
  const [userData, setLocalUserData] = useState<any>(null);

  const userId = (session as any)?.discordUser?.id || session?.user?.name || '';
  const guildId = selectedGuild?.id || '';

  useEffect(() => {
    if (guildId && userId) {
      fetch(`/api/user?guildId=${guildId}&userId=${userId}`)
        .then(r => r.json())
        .then(data => setLocalUserData(data))
        .catch(() => {});
    }
  }, [guildId, userId]);

  const tabs = [
    { id: 'fishing', label: 'Câu Cá', icon: <Fish className="w-4 h-4" />, color: 'text-cyan-400' },
    { id: 'cave', label: 'Hang Động', icon: <Mountain className="w-4 h-4" />, color: 'text-amber-400' },
    { id: 'lab', label: 'Phòng Lab', icon: <FlaskConical className="w-4 h-4" />, color: 'text-emerald-400' },
    { id: 'forge', label: 'Rèn', icon: <Hammer className="w-4 h-4" />, color: 'text-orange-400' },
    { id: 'economy', label: 'Kinh Tế', icon: <Coins className="w-4 h-4" />, color: 'text-yellow-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460]">
      {/* Top Bar */}
      <div className="sticky top-0 z-50 bg-[#1a1a2e]/90 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white h-8 w-8 p-0"
              onClick={() => setSelectedGuild(null as any)}
            >
              <ArrowLeftRight className="w-4 h-4" />
            </Button>
            {selectedGuild?.icon ? (
              <img
                src={`https://cdn.discordapp.com/icons/${guildId}/${selectedGuild.icon}.png?size=32`}
                alt=""
                className="w-6 h-6 rounded"
              />
            ) : (
              <div className="w-6 h-6 rounded bg-indigo-600/50 flex items-center justify-center text-white text-xs font-bold">
                {selectedGuild?.name?.charAt(0)}
              </div>
            )}
            <span className="text-white font-medium text-sm truncate max-w-[120px]">{selectedGuild?.name}</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-yellow-500/30 text-yellow-300 text-[10px]">
              💰 {(userData?.coins || 0).toLocaleString()}
            </Badge>
            <Avatar className="w-7 h-7 border border-indigo-500/30">
              <AvatarImage src={session?.user?.image || ''} className="w-7 h-7" />
              <AvatarFallback className="bg-indigo-600 text-white text-[10px]">
                {session?.user?.name?.charAt(0)}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-4 py-4">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'fishing' && <FishingGame guildId={guildId} userId={userId} />}
          {activeTab === 'cave' && <CaveGame guildId={guildId} userId={userId} />}
          {activeTab === 'lab' && <LabGame guildId={guildId} userId={userId} />}
          {activeTab === 'forge' && <ForgeGame guildId={guildId} userId={userId} />}
          {activeTab === 'economy' && <EconomyPanel guildId={guildId} userId={userId} />}
        </motion.div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#1a1a2e]/95 backdrop-blur-xl border-t border-white/10 z-50">
        <div className="max-w-lg mx-auto flex">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex flex-col items-center py-2.5 transition-colors ${
                activeTab === tab.id ? tab.color : 'text-slate-500'
              }`}
            >
              {tab.icon}
              <span className="text-[10px] mt-0.5">{tab.label}</span>
              {activeTab === tab.id && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute top-0 w-12 h-0.5 bg-white rounded-full"
                  style={{ left: `calc(${(tabs.indexOf(tab) / tabs.length) * 100}% + ${100 / tabs.length / 2}% - 24px)` }}
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom spacer for fixed nav */}
      <div className="h-16" />
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
//  MAIN APP WITH AUTH ROUTING
// ══════════════════════════════════════════════════════════════
function AppContent() {
  const { data: session, status } = useSession();
  const { selectedGuild } = useGameStore();

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#1a1a2e]">
        <Loader2 className="w-10 h-10 animate-spin text-indigo-400" />
      </div>
    );
  }

  if (!session) {
    return <LoginScreen />;
  }

  if (!selectedGuild) {
    return <ServerSelectScreen />;
  }

  return <GameDashboard />;
}

export default function Home() {
  return (
    <SessionProvider>
      <AppContent />
    </SessionProvider>
  );
}
