/**
 * Zustand store for game state management
 */
import { create } from 'zustand';

interface Guild {
  id: string;
  name: string;
  icon: string | null;
  owner: boolean;
}

interface UserData {
  coins: number;
  bank_coins: number;
  level: number;
  xp: number;
  rod: string;
  owned_rods: string[];
  bait: string;
  baits: { common: number; premium: number; legendary: number };
  inventory: any[];
  minerals: Record<string, any>;
  cave_unlocked: boolean;
  tools: { tnt: number; tnt_1ton: number; nukeclear: number };
  inventory_count: number;
}

interface GameState {
  // Auth
  user: any | null;
  guilds: Guild[];
  selectedGuild: Guild | null;

  // Game data
  userData: UserData | null;
  loading: boolean;

  // Active game tab
  activeTab: string;

  // Actions
  setUser: (user: any) => void;
  setGuilds: (guilds: Guild[]) => void;
  setSelectedGuild: (guild: Guild) => void;
  setUserData: (data: UserData) => void;
  setLoading: (loading: boolean) => void;
  setActiveTab: (tab: string) => void;
  reset: () => void;
}

const initialState = {
  user: null,
  guilds: [],
  selectedGuild: null,
  userData: null,
  loading: false,
  activeTab: 'fishing',
};

export const useGameStore = create<GameState>((set) => ({
  ...initialState,

  setUser: (user) => set({ user }),
  setGuilds: (guilds) => set({ guilds }),
  setSelectedGuild: (guild) => set({ selectedGuild: guild }),
  setUserData: (userData) => set({ userData }),
  setLoading: (loading) => set({ loading }),
  setActiveTab: (activeTab) => set({ activeTab }),
  reset: () => set(initialState),
}));
